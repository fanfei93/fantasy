package nexusrm

import (
// "testing"
)

/*
func TestCreateFileBlobStore(t *testing.T) {
	t.Skip("Needs new framework")
	rm, mock := repositoriesTestRM(t)
	defer mock.Close()

	err := CreateFileBlobStore(rm, "testname", "testpath")
	if err != nil {
		t.Error(err)
	}

	// TODO: list blobstores
}
*/

/*
func TestDeleteBlobStore(t *testing.T) {
	t.Skip("Needs new framework")
	rm, mock := repositoriesTestRM(t)
	defer mock.Close()

	err := DeleteBlobStore(rm, "testname")
	if err != nil {
		t.Error(err)
	}

	// TODO: list blobstores
}
*/
