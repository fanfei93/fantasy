# 1.0.1

## Fixed in 1.0.1

- Windows build of tos/user.go now work
- Added documentation to tos/user.go
