# TODO
* Dynamic RTT discovery
    * Compute 99th percentile for ping/ack
    * Better lower bound for ping/ack, faster failure detection
* Dynamic MTU discovery
    * Prevent lost updates, increases efficiency
