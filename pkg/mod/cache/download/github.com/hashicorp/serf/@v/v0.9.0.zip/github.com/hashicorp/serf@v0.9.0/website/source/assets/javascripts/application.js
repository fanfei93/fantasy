//= require turbolinks
//= require jquery

//= require hashicorp/sidebar
//= require hashicorp/mega-nav

//= require _simulator
